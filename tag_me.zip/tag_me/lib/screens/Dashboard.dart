import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:tag_me/components/DefaultButton.dart';

import 'package:firebase_ml_vision/firebase_ml_vision.dart';

class Dashboard extends StatefulWidget {
  @override
  _DashboardState createState() => _DashboardState();
}

class _DashboardState extends State<Dashboard> {
  File _image;
  List<Label> _labels;

  Future getImage() async {
    var image = await ImagePicker.pickImage(source: ImageSource.camera);

    setState(() {
      _image = image;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Dashboard"),
      ),
      body: Container(
        child: SafeArea(
          child: Column(
            children: <Widget>[
              Container(
                height: 300.0,
                child: _image == null
                    ? Text('No image selected.')
                    : Image.file(_image),
              ),
              DefaultButton(
                title: "Pick Image",
                onPress: _pickImagePressed,
              )
            ],
          ),
        ),
      ),
    );
  }

  void _pickImagePressed() async {
    var image = await ImagePicker.pickImage(source: ImageSource.camera);

    _labelImage();

    setState(() {
      _image = image;
    });
  }

  void _labelImage() async {
    var firebaseVisionImage = FirebaseVisionImage.fromFile(_image);
    final LabelDetector labelDetector = FirebaseVision.instance.labelDetector();
    _labels = await labelDetector.detectInImage(firebaseVisionImage);

    setState(() {});
  }
}
